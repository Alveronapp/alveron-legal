import Head from 'next/head'
import Header from '../components/Header'
import Footer from '../components/Footer'

export default function Practice() {
  return (
    <div className='min-h-screen flex flex-col'>
      <Head><title>Practice Areas — Alveron Legal</title></Head>
      <Header />
      <main className='flex-1 max-w-5xl mx-auto px-4 py-12'>
        <h1 className='text-3xl font-bold'>Practice Areas</h1>
        <ul className='mt-4 space-y-3 text-gray-700'>
          <li><b>Corporate & Startups:</b> incorporation, governance, fundraising docs</li>
          <li><b>Commercial Contracts:</b> MSAs, NDAs, vendor & partnership agreements</li>
          <li><b>Intellectual Property:</b> trademarks, licensing, IP strategy</li>
          <li><b>Dispute Resolution:</b> negotiation, mediation support</li>
          <li><b>Compliance:</b> data protection, regulatory filings</li>
        </ul>
      </main>
      <Footer />
    </div>
  )
}
