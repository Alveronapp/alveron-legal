import Head from 'next/head'
import Header from '../components/Header'
import Footer from '../components/Footer'

export default function Contact() {
  return (
    <div className='min-h-screen flex flex-col'>
      <Head><title>Contact — Alveron Legal</title></Head>
      <Header />
      <main className='flex-1 max-w-3xl mx-auto px-4 py-12'>
        <h1 className='text-2xl font-bold'>Contact</h1>
        <p className='mt-4 text-gray-700'>WhatsApp: <a href='https://wa.me/2347047648940'>07047648940</a></p>
        <p className='mt-2 text-gray-700'>Bank: GTBank — 0671922464 (Alveron)</p>
        <p className='mt-4 text-gray-500'>Disclaimer: This site does not create a lawyer-client relationship.</p>
      </main>
      <Footer />
    </div>
  )
}
