import Head from 'next/head'
import Header from '../components/Header'
import Footer from '../components/Footer'
import Link from 'next/link'

export default function Home() {
  return (
    <div className='min-h-screen flex flex-col'>
      <Head>
        <title>Alveron Legal — Truth in Motion</title>
        <meta name='description' content='Alveron Legal — corporate, contracts, IP, dispute resolution' />
        <link rel='manifest' href='/manifest.json' />
        <link rel='icon' href='/logo.svg' />
      </Head>
      <Header />
      <main className='flex-1'>
        <section className='bg-gradient-to-r from-alveronBlue to-white text-white'>
          <div className='max-w-5xl mx-auto px-4 py-20 text-center'>
            <h1 className='text-4xl font-extrabold'>Alveron Legal</h1>
            <p className='mt-4 text-xl text-gray-100'>Truth in Motion — Counsel you can count on</p>
            <p className='mt-6 max-w-2xl mx-auto text-gray-200'>Modern legal services for startups, SMEs and creators. Fast, clear, and focused on outcomes.</p>
            <div className='mt-8 flex justify-center gap-4'>
              <Link href='/book'><a className='bg-alveronGold text-white px-6 py-3 rounded-md font-semibold'>Book Consultation</a></Link>
              <a href='https://wa.me/2347047648940' target='_blank' rel='noreferrer' className='border border-white px-6 py-3 rounded-md'>WhatsApp Us</a>
            </div>
          </div>
        </section>

        <section className='max-w-5xl mx-auto px-4 py-12'>
          <h2 className='text-2xl font-bold'>Practice Areas</h2>
          <div className='mt-6 grid grid-cols-1 sm:grid-cols-2 gap-6'>
            <div className='p-6 border rounded-md'>
              <h3 className='font-semibold'>Corporate & Startups</h3>
              <p className='mt-2 text-sm text-gray-600'>Incorporation, governance, fundraising docs.</p>
            </div>
            <div className='p-6 border rounded-md'>
              <h3 className='font-semibold'>Commercial Contracts</h3>
              <p className='mt-2 text-sm text-gray-600'>MSAs, NDAs, vendor & partnership agreements.</p>
            </div>
            <div className='p-6 border rounded-md'>
              <h3 className='font-semibold'>Intellectual Property</h3>
              <p className='mt-2 text-sm text-gray-600'>Trademarks, licensing, IP strategy.</p>
            </div>
            <div className='p-6 border rounded-md'>
              <h3 className='font-semibold'>Dispute Resolution</h3>
              <p className='mt-2 text-sm text-gray-600'>Negotiation, mediation support.</p>
            </div>
          </div>
        </section>

        <section className='bg-gray-50'>
          <div className='max-w-5xl mx-auto px-4 py-12 text-center'>
            <h2 className='text-2xl font-bold'>Testimonials</h2>
            <div className='mt-4 space-y-4 text-gray-700'>
              <blockquote>“Alveron Legal protected our IP during a critical launch — fast and precise.” — Startup Founder</blockquote>
              <blockquote>“Clear fee structure and great communication.” — SME Owner</blockquote>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
