import Head from 'next/head'
import Header from '../components/Header'
import Footer from '../components/Footer'

export default function About() {
  return (
    <div className='min-h-screen flex flex-col'>
      <Head><title>About — Alveron Legal</title></Head>
      <Header />
      <main className='flex-1 max-w-5xl mx-auto px-4 py-12'>
        <h1 className='text-3xl font-bold'>About Alveron Legal</h1>
        <p className='mt-4 text-gray-700'>Alveron Legal is a client-first practice focused on business law. Our mission: Truth in Motion — protect your interests and accelerate your growth.</p>
      </main>
      <Footer />
    </div>
  )
}
