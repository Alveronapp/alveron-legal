import Head from 'next/head'
import Header from '../components/Header'
import Footer from '../components/Footer'
import { useState } from 'react'

export default function Book() {
  const [name, setName] = useState(''); const [email, setEmail] = useState(''); const [phone, setPhone] = useState(''); const [matter, setMatter] = useState(''); const [msg, setMsg] = useState('');
  const submit = (e) => { e.preventDefault(); alert('Thanks — request received (demo).'); setName(''); setEmail(''); setPhone(''); setMatter(''); setMsg(''); }
  return (
    <div className='min-h-screen flex flex-col'>
      <Head><title>Book Consultation — Alveron Legal</title></Head>
      <Header />
      <main className='flex-1 max-w-3xl mx-auto px-4 py-12'>
        <h1 className='text-2xl font-bold'>Book a Consultation</h1>
        <p className='mt-2 text-gray-700'>Initial consults are 20–30 minutes. WhatsApp: 07047648940</p>
        <form onSubmit={submit} className='mt-6 space-y-4'>
          <input value={name} onChange={e=>setName(e.target.value)} required placeholder='Full name' className='w-full border px-3 py-2 rounded' />
          <input value={email} onChange={e=>setEmail(e.target.value)} required type='email' placeholder='Email' className='w-full border px-3 py-2 rounded' />
          <input value={phone} onChange={e=>setPhone(e.target.value)} placeholder='Phone' className='w-full border px-3 py-2 rounded' />
          <input value={matter} onChange={e=>setMatter(e.target.value)} placeholder='Matter (short)' className='w-full border px-3 py-2 rounded' />
          <textarea value={msg} onChange={e=>setMsg(e.target.value)} placeholder='Brief summary' className='w-full border px-3 py-2 rounded' rows='5'></textarea>
          <div className='flex gap-3'><button className='bg-alveronBlue text-white px-4 py-2 rounded'>Request Consultation</button><a className='bg-green-500 text-white px-4 py-2 rounded' href='https://wa.me/2347047648940'>WhatsApp</a></div>
        </form>
      </main>
      <Footer />
    </div>
  )
}
