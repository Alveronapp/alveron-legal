module.exports = {
  content: ['./pages/**/*.{js,jsx}', './components/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        alveronBlue: '#0b3d91',
        alveronGold: '#d4af37'
      }
    }
  },
  plugins: [],
}
