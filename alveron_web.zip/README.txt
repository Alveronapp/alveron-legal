Alveron Legal — PWA (Next.js + Tailwind) — Deployment bundle
-----------------------------------------------------------

Files included:
- package.json
- next.config.js
- tailwind.config.js
- postcss.config.js
- pages/ (React pages)
- components/ (Header, Footer)
- public/ (logo.svg, manifest.json)

Local development (requires Node.js 18+):
1. cd to project root
2. npm install
3. npm run dev
4. Open http://localhost:3000

Build for production:
1. npm run build
2. npm start

Deploy to Vercel (recommended, free tier):
1. Create a GitHub repository and push these files
2. Sign in to https://vercel.com and import the repo
3. Use default build settings (Framework: Next.js). Vercel will build & deploy and give you a live URL.

I can also deploy it to Vercel for you if you give me access to push to a GitHub repo or authorize via the Vercel GitHub import. If you prefer, I can generate a ZIP (done here) and guide you step-by-step to deploy it yourself.
