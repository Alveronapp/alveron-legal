import Link from 'next/link'

export default function Header() {
  return (
    <header className='bg-white shadow-sm'>
      <div className='max-w-5xl mx-auto px-4 py-4 flex items-center justify-between'>
        <div className='flex items-center gap-3'>
          <img src='/logo.svg' alt='Alveron' className='h-10 w-10' />
          <div>
            <div className='font-bold text-lg text-alveronBlue'>Alveron Legal</div>
            <div className='text-sm text-gray-500'>Truth in Motion</div>
          </div>
        </div>
        <nav className='hidden md:flex gap-4 text-sm'>
          <Link href='/' className='hover:text-alveronBlue'>Home</Link>
          <Link href='/about' className='hover:text-alveronBlue'>About</Link>
          <Link href='/practice' className='hover:text-alveronBlue'>Practice Areas</Link>
          <Link href='/book' className='hover:text-alveronBlue'>Book</Link>
          <Link href='/contact' className='hover:text-alveronBlue'>Contact</Link>
        </nav>
        <div className='flex items-center gap-3'>
          <a href='https://wa.me/2347047648940' target='_blank' rel='noopener noreferrer' className='bg-green-500 text-white px-3 py-2 rounded-md text-sm'>WhatsApp</a>
          <a href='/#book' className='border border-alveronBlue text-alveronBlue px-3 py-2 rounded-md text-sm'>Book</a>
        </div>
      </div>
    </header>
  )
}
