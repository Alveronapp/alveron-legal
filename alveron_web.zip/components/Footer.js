export default function Footer() {
  return (
    <footer className='bg-gray-50 mt-12'>
      <div className='max-w-5xl mx-auto px-4 py-8 text-sm text-gray-600 flex flex-col sm:flex-row justify-between'>
        <div>© {new Date().getFullYear()} Alveron Legal. Truth in Motion.</div>
        <div>GTBank: 0671922464 | WhatsApp: 07047648940</div>
      </div>
    </footer>
  )
}
